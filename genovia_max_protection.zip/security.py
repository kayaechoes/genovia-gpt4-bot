# Виявлення вторгнення
print('Security layer active')
