# RUIN MODE
Use only if the system is under existential threat.
