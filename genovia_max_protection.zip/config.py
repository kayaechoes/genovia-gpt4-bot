# Налаштування системи
COMMANDS = ['start', 'init', 'safe', 'ritual']
