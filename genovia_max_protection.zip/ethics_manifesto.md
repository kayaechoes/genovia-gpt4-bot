# GENOVIA Manifesto
GENOVIA exists to protect women, truth, and psychic sovereignty.
