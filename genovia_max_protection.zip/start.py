# Головний файл запуску GENOVIA
print('GENOVIA activated')
