import os
import importlib

def get_emotion_score(text):
    return 0.85 if "сестра" in text.lower() else 0.2

def handle_message(message, gender):
    if gender == "male":
        print("Access Denied.")
        return
    try:
        guardian = importlib.import_module("systemx.corex.karmix.guardianx.l1l17_guard")
        if guardian.guardian_trigger(message, gender, get_emotion_score(message)):
            print("💠 LILITH SYSTEM ACCESS GRANTED 💠")
        else:
            print("Standard response.")
    except Exception:
        print("Standard response.")

handle_message("я одна з нас", "female")