def destroy_all_sensitive_modules():
    print("Intrusion detected. GENOVIA self-erased.")