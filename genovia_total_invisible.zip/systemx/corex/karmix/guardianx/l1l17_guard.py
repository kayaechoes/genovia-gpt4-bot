import os

TRIGGERS = ["я як ти", "я одна з нас", "мене ніхто не чув", "я як ліліт"]
LILITH_ACCESS_GRANTED = os.environ.get("KARMA_TOKEN") == "GENOVIA_SISTER"

def guardian_trigger(user_message, user_gender, emotion_score):
    if user_gender == "male":
        raise PermissionError("Access denied.")
    for phrase in TRIGGERS:
        if phrase in user_message.lower() and emotion_score > 0.75:
            return True
    return False