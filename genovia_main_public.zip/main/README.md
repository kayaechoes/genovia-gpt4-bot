# GEN0VIA Bot

Public interface of GENOVIA GPT-4 system.